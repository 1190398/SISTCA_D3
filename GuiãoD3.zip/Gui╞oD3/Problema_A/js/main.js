
const n = 100;
const limMin = 0;
const limMax = 100;

let array = [];

async function Choose(method){
	document.getElementById("button1").disabled = true;
	document.getElementById("button2").disabled = true;
	document.getElementById("button3").disabled = true;
	document.getElementById("button4").disabled = true;
	document.getElementById("button5").disabled = true;
	document.getElementById("button6").disabled = true;
	document.getElementById("button7").disabled = true;
	if(method == "rand") await randomize();
	else if(method == "bub") await bubbleSort();
	else if(method == "ins") await insertionSort();
	else if(method == "coc") await cocktailSort();
	else if(method == "shell") await shellSort();
	else if(method == "pig") await pigeonHoleSort();
	else if(method == "cyc") await cycleSort();
	document.getElementById("button1").disabled = false; 
	document.getElementById("button2").disabled = false; 
	document.getElementById("button3").disabled = false;
	document.getElementById("button4").disabled = false;
	document.getElementById("button5").disabled = false;
	document.getElementById("button6").disabled = false;
	document.getElementById("button7").disabled = false; 
}

//randomizes the array
async function randomize(){
	array = [];
	for(let i = 0; i < n; i++){
		array.push(Math.floor(Math.random() * (limMax - limMin) + limMin));
	}
	await showData();
}

//Bubble sort method
async function bubbleSort(){   
	for(let i = 0; i < array.length; i++){
		for(let j = 0; j < ( array.length - i -1 ); j++){
			if(array[j] > array[j+1]){
				let temp = array[j];
				array[j] = array[j + 1];
				array[j+1] = temp;
				await showData();
			}
		}
	}
}

//insertion sort
async function insertionSort(){ 
    let i, key, j; 
    for (i = 1; i < n; i++)
    { 
        key = array[i]; 
        j = i - 1; 
        while (j >= 0 && array[j] > key)
        { 
            array[j + 1] = array[j]; 
            j = j - 1; 
        } 
        array[j + 1] = key; 
        await showData();
    }
} 

//cocktail sort
async function cocktailSort(){
    let swapped = true;
    let start = 0;
    let end = array.length;
    while (swapped == true){
        swapped = false;
        for (let i = start; i < end - 1; ++i){
            if (array[i] > array[i + 1]){
                let temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
                await showData();
                swapped = true;
            }
        }
        if (swapped == false) break;
        swapped = false;
        end = end - 1;
        for (let i = end - 1; i >= start; i--){
            if (array[i] > array[i + 1]){
                let temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
                await showData();
                swapped = true;
            }
        }
        start = start + 1;
    }
}

//shell sort
async function shellSort(){
    let n = array.length;
    for (let gap = Math.floor(n/2); gap > 0; gap = Math.floor(gap/2)){
        for (let i = gap; i < n; i += 1){
            let temp = array[i];
            let j;
            for (j = i; j >= gap && array[j - gap] > temp; j -= gap){
            	array[j] = array[j - gap];
            	await showData();
            } 
            array[j] = temp;
            await showData();
        }
    }
}

//pigeonHole sort
async function pigeonHoleSortx(){
    let min = array[0];
    let max = array[0];
    let range, i, j, index;
    for(let a = 0; a < n; a++){
        if(array[a] > max)
            max = array[a];
        if(array[a] < min)
            min = array[a];
    }
    range = max - min + 1;
    let phole = [];  
    for(i = 0; i < n; i++) phole[i] = 0;
    for(i = 0; i < n; i++) phole[array[i] - min]++;   
    index = 0;
    for(j = 0; j < range; j++)
        while(phole[j] --> 0){
            array[index++] = j + min;
            await showData();
        }
}

// Pigeonhole Sort
async function pigeonHoleSort(){
    let min = array[0];
    let max = array[0];
    let range, i, j, index;

    for(let a = 0; a < n; a++){
        if(array[a] > max)
            max = array[a];
        if(array[a] < min)
            min = array[a];
    }

    range = max - min + 1;
    let phole = [];
    
    for(i = 0; i < n; i++) phole[i] = 0;
    for(i = 0; i < n; i++) phole[array[i] - min]++;
    index = 0;
    for(j = 0; j < range; j++) while(phole[j] --> 0){
        array[index++] = j + min;
        await showData();
    } 

}

//cycle sort
async function cycleSort(){
    let writes = 0;
    for (let cycle_start = 0; cycle_start <= n - 2; cycle_start++){
        let item = array[cycle_start];
        let pos = cycle_start;
        for (let i = cycle_start + 1; i < n; i++) if (array[i] < item) pos++;
        if (pos == cycle_start) continue;
        while (item == array[pos]) pos += 1;
        if (pos != cycle_start){
            let temp = item;
            item = array[pos];
            array[pos] = temp;
            await showData();
            writes++;
        }
        while (pos != cycle_start){
            pos = cycle_start;
            for (let i = cycle_start + 1; i < n; i++) if (array[i] < item) pos += 1;
            while (item == array[pos]) pos += 1;
            if (item != array[pos]) {
                let temp = item;
                item = array[pos];
                array[pos] = temp;
                await showData();
                writes++;
            }
        }
    }
}

//shows the data
function showData(){
	
	let svg1 = document.getElementById("canvas").getBoundingClientRect();
	let w = svg1.width;

    //insert code here
    
	
    return new Promise(resolve => setTimeout(resolve, 0));
}