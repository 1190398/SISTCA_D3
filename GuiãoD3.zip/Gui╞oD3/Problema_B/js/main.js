let x;
let y;

let walls = [];

document.addEventListener('mousemove', function(e){ //Saves the mouse position in x and y
	x = e.x - 7;
	y = e.y - 3.4 * document.getElementById('head').offsetHeight;
});

function randomize(){	//generates random walls
	let width = document.getElementById('canvas').offsetWidth;
	let height = document.getElementById('canvas').offsetHeight;
	walls = [ 	{x1: 0, x2: width, y1: 0, y2: 0},				//initial boundary walls
				{x1: 0, x2: 0, y1: 0, y2: height},
				{x1: width, x2: width, y1: 0, y2: height},
				{x1: 0, x2: width, y1: height, y2: height},
	];

	for(let i = 0; i < 10; i++){								//random walls
		let x1 = Math.random()*width;
		let y1 = Math.random()*height;
		let x2 = Math.random()*width;
		let y2 = Math.random()*height;
		walls.push(new Wall(x1, y1, x2, y2));
	}
}

async function draw(svg){										//draw function

	//draw black background

	//draw walls

	//draw light
	for(let i = 0; i < 360; i+=1){					//360 lines (one for each degree)
		x1 = x;
		y1 = y;
		x2 = x + 2*Math.cos(i * 3.14159/180);
		y2 = y + 2*Math.sin(i * 3.14159/180);
		let interX = x2;
		let interY = y2;
		let distance = 50000;
		walls.forEach(wall => {					//for each wall, tests is theres an intersection
			x3 = wall.x1;
			y3 = wall.y1;
			x4 = wall.x2;
			y4 = wall.y2;
			//intersection math
			let den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
			let t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den;
			let u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den;
			if(t > 0 && u > 0 && u < 1){			//if theres an intersection
				let tempX = x1 + t * (x2 - x1);		//intersection x
				let tempY = y1 + t * (y2 - y1);		//intersection y
				if(Math.sqrt((tempX-x)*(tempX-x)+(tempY-y)*(tempY-y)) < distance){	//saves the closest intersection for that line in interX and interY
					distance = Math.sqrt((tempX-x)*(tempX-x)+(tempY-y)*(tempY-y));
					interX = tempX;
					interY = tempY;
				}			
			}


		});
		//insert code that draws the lines here
		/*


		*/
	}
	//insert code that draws the circle here
	/*


	*/

	return new Promise(resolve => setTimeout(resolve, 0));
}


async function main(){
	//insert main code here
	/*



	*/

	await draw(svg);				//calls draw function ang waits for it to finish
}