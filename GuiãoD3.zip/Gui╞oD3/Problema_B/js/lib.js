class Wall{					//wall object
	constructor(a, b, c, d){
		this.x1 = a;
		this.y1 = b;
		this.x2 = c;
		this.y2 = d;
	}
}