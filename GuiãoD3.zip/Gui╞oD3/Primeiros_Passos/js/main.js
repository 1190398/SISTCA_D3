
function draw(){
	
	let w = window.innerWidth/2;
	let h = window.innerHeight/2 - 150;

	d3.select("#drawSvg").remove();

	let svg = d3.select("#canvas")
		.append("svg")
		.attr("id", "drawSvg")
		.attr("width", "100%")
		.attr("height", "450")

	svg.append("rect")
		.attr("x", 0)
		.attr("y", 0)
		.attr("width", w*2)
		.attr("height", (h+150)*2)
		.style("fill", "#D6D6D6")

	svg.append("line")
		.attr("x1", w)
		.attr("y1", h)
		.attr("x2", w)
		.attr("y2", 4*h)
		.style("stroke", "black")
		.style("stroke-width", 30)

	svg.append("rect")
		.attr("x", w - 100)
		.attr("y", h + 250)
		.attr("width", 200)
		.attr("height", 50)
		.style("fill", "black")

	svg.append("rect")
		.attr("x", w - 150)
		.attr("y", h - 150)
		.attr("width", 300)
		.attr("height", 300)
		.style("fill", "#6E2C00")

	svg.append("circle")
		.attr("cx", w)
		.attr("cy", h)
		.attr("r", 120)
		.style("fill", "#99A3A4")

	svg.append("circle")
		.attr("cx", w)
		.attr("cy", h)
		.attr("r", 90)
		.style("fill", "#187DD8")

	svg.append("circle")
		.attr("cx", w)
		.attr("cy", h)
		.attr("r", 60)
		.style("fill", "#E21706")

	svg.append("circle")
		.attr("cx", w)
		.attr("cy", h)
		.attr("r", 30)
		.style("fill", "#DDE206")

	svg.append("text")
		.attr("x", w)
		.attr("y", h + 4)
		.attr("text-anchor", "middle")
		.style("font-size", "15px")
		.text("100")
		.style("fill", "black")

	svg.append("text")
		.attr("x", w - 50)
		.attr("y", h + 4)
		.attr("text-anchor", "middle")
		.style("font-size", "15px")
		.text("60")
		.style("fill", "black")

	svg.append("text")
		.attr("x", w - 80)
		.attr("y", h + 4)
		.attr("text-anchor", "middle")
		.style("font-size", "15px")
		.text("40")
		.style("fill", "black")

	svg.append("text")
		.attr("x", w - 110)
		.attr("y", h + 4)
		.attr("text-anchor", "middle")
		.style("font-size", "15px")
		.text("20")
		.style("fill", "black")
}