
//Relevant constants
const limNegX = -10;
const limPosX = 10;
const step = 0.001;

//calculates a point of the function
function CalculatePoint(x, eq){

    let y = eval(eq);

    y = Math.round((y + Number.EPSILON) * 1000) / 1000;

    let sliderX = document.getElementById("ScaleX");
    let sliderY = document.getElementById("ScaleY");

    return{
        x: x * sliderX.value,
        y: (-1) * y * sliderY.value
    }
}

//generates the data
function generateData(){

    let points = [];

    let eq = document.getElementById("eq").value;

    for(let i = limNegX; i < limPosX; i+=step){
        i = Math.round((i + Number.EPSILON) * 1000) / 1000;

        let point = CalculatePoint(i, eq);
        if(!isNaN(point.y) && isFinite(point.y))    points.push(point);
    }

    return points;
}

//draws the referential
function referential(svg){

    var svg1 = document.getElementById("canvas").getBoundingClientRect();

    let width = svg1.width;
    let height = svg1.height;

    let sliderX = document.getElementById("ScaleX");
    let sliderY = document.getElementById("ScaleY");

    //horizontal axis
    svg.append("line")
        .attr("x1", 0)
        .attr("y1", height/2)
        .attr("x2", width)
        .attr("y2", height/2)
        .attr("stroke", "black")
        .attr("stroke-width", 1)
    //vertical axis
    svg.append("line")
        .attr("x1", width/2)
        .attr("y1", 0)
        .attr("x2", width/2)
        .attr("y2", height)
        .attr("stroke", "black")
        .attr("stroke-width", 1)

    //append 0 mark
    svg.append("text")
        .attr("x", width/2 - 15)
        .attr("y", height/2 + 15)
        .attr("font-size", 12)
        .text("0")

    //horizontal axix marks
    let i = 1;
    do{
        let pos = width/2;
        let offset = i * sliderX.value;
        svg.append("line")
            .attr("x1", pos + offset)
            .attr("y1", height/2+5)
            .attr("x2", pos + offset)
            .attr("y2", height/2-5)
            .attr("stroke", "black")
            .attr("stroke-width", 0.5)
        svg.append("line")
            .attr("x1", pos - offset)
            .attr("y1", height/2+5)
            .attr("x2", pos - offset)
            .attr("y2", height/2-5)
            .attr("stroke", "black")
            .attr("stroke-width", 0.5)
        svg.append("text")
            .attr("x", pos + offset)
            .attr("y", height/2 + 15)
            .attr("font-size", 12)
            .text(i)
        svg.append("text")
            .attr("x", pos - offset)
            .attr("y", height/2 + 15)
            .attr("font-size", 12)
            .text(-i)
        if(pos + offset > width) break;
        else i++;
    }while(true);

    //vertical axix marks
    i = 1;
    do{
        let pos = height/2;
        let offset = i * sliderY.value;
        svg.append("line")
            .attr("x1", width/2+5)
            .attr("y1", pos + offset)
            .attr("x2", width/2-5)
            .attr("y2", pos + offset)
            .attr("stroke", "black")
            .attr("stroke-width", 0.5)
        svg.append("line")
            .attr("x1", width/2+5)
            .attr("y1", pos - offset)
            .attr("x2", width/2-5)
            .attr("y2", pos - offset)
            .attr("stroke", "black")
            .attr("stroke-width", 0.5)
        svg.append("text")
            .attr("x", width/2 - 15)
            .attr("y", pos + offset)
            .attr("font-size", 12)
            .text(-i)
        svg.append("text")
            .attr("x", width/2 - 15)
            .attr("y", pos - offset)
            .attr("font-size", 12)
            .text(i)
        if(pos + offset > height) break;
        else i++;
    }while(true);
}

//shows the data
function showData(svg, data){
    //insert show data code here
    /*



    */
}

//main function
function main(){
    //insert main code here
    /*



    */
}
